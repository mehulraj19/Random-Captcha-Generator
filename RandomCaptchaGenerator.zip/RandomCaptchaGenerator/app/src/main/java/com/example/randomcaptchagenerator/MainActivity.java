package com.example.randomcaptchagenerator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.Editable;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    TextView capchaGen;
    EditText enterCapchaGen;
    Button checkButton;
    private final String mainString = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        capchaGen = findViewById(R.id.captchaText);
        enterCapchaGen = findViewById(R.id.captchaEnteredText);
        checkButton = findViewById(R.id.checkButton);

        StringBuilder s = new StringBuilder();
        int max = mainString.length();
        int min = 0;

        int i=0;
        while(i<6) {
            int index = (int)(Math.random()*(max-min+1)+min);
            s.append(mainString.charAt(index));
            i++;
        }
        capchaGen.setText(s);



        checkButton.setOnClickListener(v -> {
            String enteredString = enterCapchaGen.getText().toString();
            if(enteredString.equals(s.toString())) {
                Toast.makeText(MainActivity.this, "The Entered Text is Same!!", Toast.LENGTH_SHORT).show();
            }else {
                Toast.makeText(MainActivity.this, "The Entered Text is Not Same!!", Toast.LENGTH_SHORT).show();
            }
        });

    }
}